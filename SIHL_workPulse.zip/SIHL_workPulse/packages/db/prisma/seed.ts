/**
 * Local dev seed data. Run via `npm run db:seed`.
 *
 * This does NOT seed Employee/Department - those come exclusively from the
 * Frappe HR sync job (apps/api/src/jobs/frappe-hr-sync.job.ts), which in
 * FRAPPE_SYNC_MODE=mock generates realistic fixture employees/departments on
 * its own. Run `npm run sync:frappe-hr` after this seed to populate them.
 */
import { PrismaClient, WorkPulseRole } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding workPulse local dev data...");

  // A single bootstrap System Admin user, not tied to an Employee yet - useful
  // for logging in and exercising admin screens before the Frappe HR sync has
  // run. Replace keycloakId with your real dev Keycloak subject once the
  // Keycloak realm is imported (see docs/phase-0-setup.md).
  const admin = await prisma.user.upsert({
    where: { keycloakId: "dev-bootstrap-admin" },
    update: {},
    create: {
      keycloakId: "dev-bootstrap-admin",
      roles: [WorkPulseRole.SYSTEM_ADMIN],
    },
  });

  console.log(`Seed complete. Bootstrap admin user id: ${admin.id}`);
}

main()
  .catch((err) => {
    console.error("Seed failed:", err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
