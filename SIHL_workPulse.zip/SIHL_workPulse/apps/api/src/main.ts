import "reflect-metadata";
import { NestFactory } from "@nestjs/core";
import { ValidationPipe, Logger } from "@nestjs/common";
import { AppModule } from "./app.module";

async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    logger: ["error", "warn", "log", process.env.NODE_ENV === "development" ? "debug" : "log"],
  });

  // Reject unknown fields / coerce types at the edge, rather than trusting
  // the frontend - important once RACI/DACI/SLA payloads get more complex.
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  app.enableCors({
    origin: process.env.WEB_BASE_URL ?? "http://localhost:3000",
    credentials: true,
  });

  const port = process.env.API_PORT ?? 4000;
  await app.listen(port);
  Logger.log(`workPulse API listening on port ${port}`, "Bootstrap");
}

bootstrap();
