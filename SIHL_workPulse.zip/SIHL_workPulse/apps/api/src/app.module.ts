import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { ScheduleModule } from "@nestjs/schedule";
import { BullModule } from "@nestjs/bullmq";
import { HealthModule } from "./modules/health/health.module";
import { EmployeeModule } from "./modules/employee/employee.module";
import { AuditModule } from "./modules/audit/audit.module";
import { AuthModule } from "./modules/auth/auth.module";
import { JobsModule } from "./jobs/jobs.module";

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ScheduleModule.forRoot(), // powers the Frappe HR sync cron in Phase 0;
    // SLA/escalation/recurrence jobs plug into this same mechanism in Phase 1+
    BullModule.forRoot({
      connection: {
        url: process.env.REDIS_URL ?? "redis://localhost:6379",
      },
    }),
    AuditModule, // imported early: other modules inject AuditService to log changes
    AuthModule,
    HealthModule,
    EmployeeModule,
    JobsModule,
  ],
})
export class AppModule {}
