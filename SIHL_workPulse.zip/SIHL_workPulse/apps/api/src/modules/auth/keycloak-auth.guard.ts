import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import type { Request } from "express";
import { IS_PUBLIC_KEY } from "./public.decorator";
import { KeycloakTokenService } from "./keycloak-token.service";

/**
 * Global guard, registered in AuthModule. Verifies the bearer token against
 * Keycloak's JWKS endpoint and attaches the decoded token to the request.
 *
 * Phase 0 note: this guard is fully wired but will reject every request
 * until a real Keycloak realm is running (docker compose up) and
 * KEYCLOAK_* env vars point at it - see docs/phase-0-setup.md. That is
 * intentional: workPulse should fail closed on auth, not fail open.
 */
@Injectable()
export class KeycloakAuthGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly tokenService: KeycloakTokenService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) return true;

    const request = context.switchToHttp().getRequest<Request>();
    const token = this.extractBearerToken(request);
    if (!token) {
      throw new UnauthorizedException("Missing bearer token");
    }

    const decoded = await this.tokenService.verify(token);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (request as any).authToken = decoded;
    return true;
  }

  private extractBearerToken(request: Request): string | undefined {
    const header = request.headers.authorization;
    if (!header?.startsWith("Bearer ")) return undefined;
    return header.slice("Bearer ".length);
  }
}
