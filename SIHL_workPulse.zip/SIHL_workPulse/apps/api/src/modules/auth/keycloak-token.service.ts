import { Injectable, UnauthorizedException } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";

export interface DecodedKeycloakToken {
  sub: string; // Keycloak user id -> User.keycloakId
  email?: string;
  preferred_username?: string;
  realm_access?: { roles: string[] };
  exp: number;
}

/**
 * Verifies Keycloak-issued JWTs against the realm's JWKS endpoint.
 *
 * Deliberately dependency-light: rather than pulling in a full OIDC client
 * library for Phase 0, this documents exactly what Phase 1 needs to wire up
 * (fetch + cache JWKS, verify signature + exp + issuer) so it's an explicit,
 * reviewable piece of security-critical code rather than a black box.
 * Swap in `jose` (recommended) or `nest-keycloak-connect` here once the
 * Keycloak realm is live - see docs/phase-0-setup.md.
 */
@Injectable()
export class KeycloakTokenService {
  constructor(private readonly config: ConfigService) {}

  async verify(_token: string): Promise<DecodedKeycloakToken> {
    const baseUrl = this.config.get<string>("KEYCLOAK_BASE_URL");
    const realm = this.config.get<string>("KEYCLOAK_REALM");

    if (!baseUrl || !realm) {
      throw new UnauthorizedException(
        "Keycloak is not configured (KEYCLOAK_BASE_URL / KEYCLOAK_REALM missing) - see .env.example",
      );
    }

    // TODO (Phase 1, before any real auth traffic): implement real JWKS
    // verification. Suggested shape:
    //
    //   import { createRemoteJWKSet, jwtVerify } from "jose";
    //   const jwks = createRemoteJWKSet(new URL(`${baseUrl}/realms/${realm}/protocol/openid-connect/certs`));
    //   const { payload } = await jwtVerify(_token, jwks, {
    //     issuer: `${baseUrl}/realms/${realm}`,
    //   });
    //   return payload as DecodedKeycloakToken;
    //
    // Cache the JWKS response (jose's createRemoteJWKSet does this internally
    // with a default cache) rather than fetching on every request.
    throw new UnauthorizedException(
      "Keycloak token verification is not yet implemented - see TODO in keycloak-token.service.ts",
    );
  }
}
