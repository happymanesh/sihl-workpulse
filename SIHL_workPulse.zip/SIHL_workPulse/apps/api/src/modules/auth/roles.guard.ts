import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import { prisma } from "@workpulse/db";
import type { WorkPulseRoleName } from "@workpulse/shared-types";
import { ROLES_KEY } from "./roles.decorator";
import type { DecodedKeycloakToken } from "./keycloak-token.service";

/**
 * Runs after KeycloakAuthGuard. Looks up the workPulse User (and its roles)
 * for the authenticated Keycloak subject, then checks against @Roles(...).
 *
 * Kept separate from KeycloakAuthGuard deliberately: authentication (who are
 * you) and authorization (what can you do) are different concerns with
 * different failure modes, and Section 18's confidential-task / Audit-role
 * rules will need this layer to grow independently of the token layer.
 */
@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const requiredRoles = this.reflector.getAllAndOverride<WorkPulseRoleName[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!requiredRoles || requiredRoles.length === 0) return true;

    const request = context.switchToHttp().getRequest();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const authToken = (request as any).authToken as DecodedKeycloakToken | undefined;
    if (!authToken) {
      throw new ForbiddenException("No authenticated user on request");
    }

    const user = await prisma.user.findUnique({ where: { keycloakId: authToken.sub } });
    if (!user) {
      throw new ForbiddenException("Authenticated identity has no workPulse user record");
    }

    const hasRole = user.roles.some((r) => requiredRoles.includes(r as WorkPulseRoleName));
    if (!hasRole) {
      throw new ForbiddenException(`Requires one of: ${requiredRoles.join(", ")}`);
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (request as any).workPulseUser = user;
    return true;
  }
}
