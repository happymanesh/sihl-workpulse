import { Module } from "@nestjs/common";
import { APP_GUARD } from "@nestjs/core";
import { KeycloakAuthGuard } from "./keycloak-auth.guard";
import { KeycloakTokenService } from "./keycloak-token.service";
import { RolesGuard } from "./roles.guard";

@Module({
  providers: [
    KeycloakTokenService,
    // Order matters: authentication before authorization on every request.
    { provide: APP_GUARD, useClass: KeycloakAuthGuard },
    { provide: APP_GUARD, useClass: RolesGuard },
  ],
  exports: [KeycloakTokenService],
})
export class AuthModule {}
