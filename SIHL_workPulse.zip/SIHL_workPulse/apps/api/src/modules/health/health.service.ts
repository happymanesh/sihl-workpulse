import { Injectable, Logger } from "@nestjs/common";
import { Redis } from "ioredis";
import { prisma } from "@workpulse/db";
import type { HealthStatus } from "@workpulse/shared-types";

@Injectable()
export class HealthService {
  private readonly logger = new Logger(HealthService.name);
  private readonly redis: Redis;

  constructor() {
    // Deliberately not injecting a shared Redis client here - health checks
    // should not depend on the same connection pool that BullMQ workers use,
    // so a stuck job queue doesn't silently make health checks pass or fail
    // for the wrong reason.
    this.redis = new Redis(process.env.REDIS_URL ?? "redis://localhost:6379", {
      lazyConnect: true,
      connectTimeout: 2000,
      maxRetriesPerRequest: 1,
    });
  }

  async check(): Promise<HealthStatus> {
    const [database, redis] = await Promise.all([this.checkDatabase(), this.checkRedis()]);

    const status: HealthStatus["status"] =
      database === "ok" && redis === "ok" ? "ok" : database === "error" && redis === "error" ? "down" : "degraded";

    return {
      status,
      service: "workpulse-api",
      version: process.env.npm_package_version ?? "0.0.1",
      timestamp: new Date().toISOString(),
      checks: { database, redis },
    };
  }

  private async checkDatabase(): Promise<"ok" | "error"> {
    try {
      await prisma.$queryRaw`SELECT 1`;
      return "ok";
    } catch (err) {
      this.logger.warn(`Database health check failed: ${(err as Error).message}`);
      return "error";
    }
  }

  private async checkRedis(): Promise<"ok" | "error"> {
    try {
      await this.redis.connect();
      const pong = await this.redis.ping();
      await this.redis.quit();
      return pong === "PONG" ? "ok" : "error";
    } catch (err) {
      this.logger.warn(`Redis health check failed: ${(err as Error).message}`);
      return "error";
    }
  }
}
