import type { HealthStatus } from "@workpulse/shared-types";

async function getApiHealth(): Promise<HealthStatus | { error: string }> {
  try {
    const res = await fetch(`${process.env.API_BASE_URL ?? "http://localhost:4000"}/health`, {
      cache: "no-store",
    });
    if (!res.ok) return { error: `API responded with ${res.status}` };
    return (await res.json()) as HealthStatus;
  } catch (err) {
    return { error: `Could not reach API: ${(err as Error).message}` };
  }
}

function StatusDot({ ok }: { ok: boolean }) {
  return <span className={`inline-block h-2.5 w-2.5 rounded-full ${ok ? "bg-green-500" : "bg-red-500"}`} />;
}

export default async function HomePage() {
  const health = await getApiHealth();
  const isError = "error" in health;

  return (
    <main className="mx-auto max-w-2xl px-6 py-16">
      <div className="mb-10 border-b-4 border-navy pb-4">
        <h1 className="text-2xl font-bold text-navy">workPulse</h1>
        <p className="text-sm text-gray-500">SIHL Work Management Platform &mdash; Phase 0 scaffold</p>
      </div>

      <section className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
        <h2 className="mb-4 text-sm font-semibold uppercase tracking-wide text-gray-500">
          Frontend &rarr; API connectivity
        </h2>

        {isError ? (
          <div className="flex items-center gap-2 text-red-700">
            <StatusDot ok={false} />
            <span>{health.error}</span>
          </div>
        ) : (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <StatusDot ok={health.status === "ok"} />
              <span className="font-medium">API status: {health.status}</span>
            </div>
            <div className="flex items-center gap-2 pl-4 text-sm text-gray-600">
              <StatusDot ok={health.checks.database === "ok"} />
              <span>Database: {health.checks.database}</span>
            </div>
            <div className="flex items-center gap-2 pl-4 text-sm text-gray-600">
              <StatusDot ok={health.checks.redis === "ok"} />
              <span>Redis: {health.checks.redis}</span>
            </div>
            <p className="pt-2 text-xs text-gray-400">Checked at {health.timestamp}</p>
          </div>
        )}

        {isError && (
          <p className="mt-4 text-sm text-gray-500">
            If this is your first run, start local infrastructure first: <code>docker compose up -d</code>, then{" "}
            <code>npm run dev</code> from the repo root. See <code>docs/phase-0-setup.md</code>.
          </p>
        )}
      </section>

      <p className="mt-8 text-sm text-gray-400">
        This page is intentionally minimal &mdash; it exists to prove the stack is wired together end to end.
        Phase 1 replaces it with the My Tasks view from the wireframes.
      </p>
    </main>
  );
}
