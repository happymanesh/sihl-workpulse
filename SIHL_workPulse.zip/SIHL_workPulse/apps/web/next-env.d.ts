/// <reference types="next" />
/// <reference types="next/image-types/global" />

// NOTE: Next.js normally regenerates this file automatically on `next dev`
// or `next build`. It is committed here so a fresh checkout typechecks
// before the first dev-server run. Do not hand-edit beyond this comment.
