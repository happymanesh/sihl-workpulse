/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx,mdx}", "./components/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        // Placeholder navy matching the BRS/wireframe documents - swap for
        // the real SIHL brand palette once the rebrand exercise lands.
        navy: "#1F3A5F",
      },
    },
  },
  plugins: [],
};
