# CLAUDE.md - context for working on SIHL workPulse

You are continuing a build that started in a planning conversation elsewhere.
This file is the handoff. Read it fully before making changes.

## What this is

**workPulse** is SIHL's Enterprise Work Management Platform - task, project
and team execution, RACI/DACI governance, SLA/escalation, MIS with
drill-down, an eventual CEO Command Centre feed, and employee performance
evidence (KRA + Beyond-KRA scoring) feeding HR appraisal.

**Reference material - read these before building any module:**
- `docs/reference/SIHL_WMP_Business_Requirement_Specification.docx` - the
  full BRS. Section numbers referenced throughout this codebase (e.g.
  "Section 14", "TM-FR-029") point here. Appendix A is the literal
  functional-requirements backlog; Appendix F is open decisions.
- `docs/reference/SIHL_WMP_UI_Wireframes.pdf` - 8 low-fidelity screens
  (My tasks, task detail, Kanban, team workload, enterprise dashboard,
  project view, recurring task setup, exit checklist), each annotated
  back to BRS requirement IDs.

## Critical architectural decision: this is NOT built on Frappe

SIHL's other systems (Vision/CRM, SIHL-One) run on Frappe. workPulse is a
deliberate departure from that, built fresh with this stack. The one thing
that does NOT change: **Frappe HR remains the sole source of truth for
Employee/Department data.** workPulse reads a cache of it
(`apps/api/src/jobs/frappe-hr-sync.ts`), it never becomes a second place
employee data can drift from. Do not add employee/department write paths
to this app outside that sync job.

## Stack and why

| Layer | Choice | Why |
|---|---|---|
| Frontend | Next.js 14 (App Router, TS) | Server components fit the read-heavy MIS/dashboard screens well |
| Backend | NestJS (TS) | Modules map 1:1 onto BRS sections (Task, Project, SLA, RACI/DACI...); DI makes the audit/RBAC cross-cutting concerns easy to enforce consistently |
| API contract | REST now; tRPC is the intended end-state between web and api once the module surface stabilizes past Phase 0 - don't add GraphQL |
| DB | PostgreSQL + Prisma | Relational fit for dependencies/hierarchies/RACI; Prisma migrations are the single source of truth for schema history |
| Jobs | Redis + BullMQ | Recurring task generation, SLA evaluation, escalation, notification digests - same pattern as the sync job, don't invent a second job system |
| Auth | Keycloak | SSO-capable if SIHL standardizes on it enterprise-wide later; do not replace with a bespoke auth system |
| Storage | S3-compatible (MinIO locally) | Attachments |

## Conventions

- **TypeScript everywhere, strict mode.** No `any` without a comment explaining why (the two guard files that use it for request augmentation are the accepted exceptions - see `roles.guard.ts`, `keycloak-auth.guard.ts`).
- **Every schema change is a Prisma migration.** Never hand-edit the DB. Run `npm run db:migrate -w packages/db` and commit the generated migration folder.
- **Every mutating action gets an AuditService.record() call.** Section 19 of the BRS: who changed what, from what, to what, when, why. Look at `apps/api/src/modules/audit/audit.service.ts` for the pattern: capture `before`, perform the mutation, capture `after`, record with a `reason` for anything the BRS's business rules mark as requiring one (reassignment, reopening, cancellation, priority escalation to Critical/Management).
- **RBAC via `@Roles(...)` on every controller method that isn't `@Public()`.** No bare controllers. Confidential-task visibility rules (Section 18) will need row-level checks beyond what `@Roles()` alone can express - build that as a service-layer check, not a guard, once the Task module exists.
- **Business rules from the BRS are not optional nice-to-haves - they're the spec.** E.g. "a task cannot close without completion information", "exactly one Accountable per RACI-enabled task", "SLA clock pauses while Blocked". Implement the rule, write a test for it, don't just build the happy path.

## Build order (do not skip ahead)

Follow the BRS's own phasing (Section 24), broken into buildable slices.
Each Appendix A row (`TM-FR-xxx`) is a ready-made ticket - use them directly
rather than re-deriving requirements from the narrative sections.

1. **Phase 0 (this checkout)** - foundations. Done: monorepo, auth scaffold,
   Frappe HR sync (mock mode), audit log, health checks, CI. **Not done, do
   first:** real Keycloak JWT verification (`keycloak-token.service.ts` has
   the exact TODO), then wire a real login flow into `apps/web`.
2. **Phase 1** - Task, Project, Team modules in that order (TM-FR-001
   through TM-FR-044ish). Build the Task lifecycle state machine (Section 14)
   as an explicit state machine, not a free-text status field - the
   Completed vs. Verified vs. Closed distinction and the
   Draft/Rejected/Reopened/Cancelled/On-Hold/Deferred side-states are load-bearing,
   not decoration. Build the wireframed screens (My tasks, Task detail,
   Kanban) against real data as each module lands, rather than all UI at the end.
3. **Phase 2** - RACI/DACI, SLA/escalation engine, source-system integration
   (Support Desk first per Appendix F), unscored KRA/Beyond-KRA analytics
   (employee + manager visibility ONLY - do not expose to HR yet), fairness/
   anti-gaming controls (Section 15.17) and the score dispute mechanism.
   **Ship the fairness controls in the same slice as any scoring UI, not after.**
4. **Phase 3** - CEO Command Centre feed, weighted composite scoring (only
   after Phase 2's fairness controls have run for real), HR Appraisal feed,
   ML service (SLA-breach prediction first).

## Things to not do

- Don't duplicate Employee/Department as writable local data.
- Don't ship a weighted performance score without the dispute mechanism and
  anti-gaming controls landing first - this was a deliberate, discussed
  decision, not an oversight to "fix" by building the score sooner.
- Don't introduce a second background-job system alongside BullMQ.
- Don't build Frappe-style low-code admin screens for master data - plain
  CRUD UIs in `apps/web` are fine and preferred; this app deliberately
  traded Frappe's low-code speed for a stack Claude Code can reason about
  end to end.

## Open decisions still needed from SIHL (don't guess at these)

See Appendix F of the BRS for the full list (~30 items across 15
categories). The ones most likely to block early Phase 1/2 work:
- Hosting/data-residency region (BRS assumed AWS ap-south-1; confirm with Compliance)
- Whether Task-level RACI ships in Phase 1 vs. Phase 2 (BRS recommends Phase 2, Project-level only in Phase 1)
- KRA/Beyond-KRA score weighting formula, and who signs off on it
