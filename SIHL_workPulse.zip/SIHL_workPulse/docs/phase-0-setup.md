# Phase 0 setup guide

Follow these steps in order on a fresh checkout.

## Prerequisites

- Node.js 20+
- Docker Desktop (for Postgres, Redis, Keycloak, MinIO)
- Git

## 1. Install dependencies

```
npm install
```

This installs all four workspaces (`apps/web`, `apps/api`, `packages/db`, `packages/shared-types`) in one pass via npm workspaces.

## 2. Start local infrastructure

```
docker compose up -d
```

Brings up Postgres (5432), Redis (6379), Keycloak (8080), MinIO (9000/9001), and Adminer (8081, a simple DB browser). Keycloak auto-imports the `workpulse` realm from `docs/keycloak/workpulse-realm.json` on first boot - give it 30-60 seconds to finish importing before the API can authenticate against it.

## 3. Configure environment

```
cp .env.example .env
```

Defaults match `docker-compose.yml` and will work as-is for local dev. Leave `FRAPPE_SYNC_MODE=mock` until real SIHL Frappe HR API credentials are available (see step 6).

## 4. Set up the database

```
npm run db:generate
npm run db:migrate -w packages/db
```

The second command creates the first Prisma migration from `packages/db/prisma/schema.prisma` and applies it. It will prompt for a migration name - `init` is fine.

## 5. Seed and sync

```
npm run db:seed
npm run sync:frappe-hr
```

The seed creates a bootstrap admin `User` row. The sync pulls mock Employee/Department fixture data (7 employees, 5 departments) so the rest of the app has realistic data to build against.

## 6. Run the app

```
npm run dev
```

Starts both `apps/api` (port 4000) and `apps/web` (port 3000) concurrently. Open http://localhost:3000 - it should show green status dots for API/database/redis connectivity.

## 7. Verify

```
npm run typecheck
npm run lint
npm run test -w apps/api
```

All three should pass on a clean Phase 0 checkout.

---

## Known gaps to close before Phase 1 auth work starts

These are the two pieces deliberately left as documented stubs rather than guessed at:

1. **Keycloak JWT verification** (`apps/api/src/modules/auth/keycloak-token.service.ts`) - the guard structure, `@Public()`/`@Roles()` decorators, and fail-closed behavior are real and wired in; the actual JWKS signature verification has a TODO with the exact `jose` snippet to drop in. Do this before any real auth traffic hits the API.
2. **Live Frappe HR client** (`apps/api/src/jobs/frappe-hr-client.ts`) - needs SIHL's actual Frappe instance URL and API key/secret, plus confirmation of the Employee/Department doctype field names against SIHL's real instance (they may be customised). Until then, `FRAPPE_SYNC_MODE=mock` keeps everything else buildable and testable.

## Rotate before this goes anywhere near production

Every credential in `.env.example` and `docs/keycloak/workpulse-realm.json` (`workpulse_dev_password`, `changeme-in-real-env`, etc.) is a placeholder for local dev only. Rotate all of them via proper secrets management before staging/production.
